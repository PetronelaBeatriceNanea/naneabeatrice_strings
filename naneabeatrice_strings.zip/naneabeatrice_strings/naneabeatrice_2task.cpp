#include <iostream>
using namespace std;
typedef struct id
{
    int info;
    struct id *next;
} element;

typedef struct
{
    element *st,*sf,*curent;
    int counter;
} lista;

lista *initstack(lista *l)
{
    lista *somelist;
    somelist=new lista;
    somelist->st=NULL;
    somelist->sf=NULL;
    somelist->curent=NULL;
    somelist->counter=0;
    return somelist;
}


lista *push(lista *l, int somevalue)
{
    if((*l).counter==0)
    {
        element *newone;
        newone=new element;
        newone->info=somevalue;
        newone->next=NULL;
        l->st=newone;
        l->sf=newone;
        l->curent=newone;
        l->counter++;
    }
    else
    {
        element *newone;
        newone=new element;
        newone->info=somevalue;
        newone->next=NULL;
        l->sf->next=newone;
        l->sf=newone;
        l->curent=newone;
        l->counter++;
    }
    return l;
}

lista *l;
int main()
{
    l=new lista;
    l=initstack(l);
    for(int i=1;i<=10;i++)
    {
        l=push(l, i);
    }
    l->curent=l->st;
    while(l->curent!=NULL)
    {
        cout<<l->curent->info<<" ";
        l->curent=l->curent->next;
    }
}
