#include <iostream>
using namespace std;
int a=27;
int b=39;
int coderoare;
int adunare(int a, int b, int *er)
{
    if (a>=(2147483647/2)&& b>=(2147483647/2))
        *er=0;
    else
        *er=1;
    return a+b;
}

int main()
{
    int result;
    result=adunare(a, b, &coderoare);
    cout<<"suma="<<result<<" cod="<<coderoare;
}
